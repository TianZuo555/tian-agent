Tian SVG avatars: 4 characters x 25 states.
Each SVG is self-contained, with a transparent background and CSS animations.
Change --planet-color on the root SVG to recolour its surface and details.
System reduced-motion preferences are respected. Use a modern browser.

idle: 空闲 — 自然眨眼，轻微呼吸。
listening: 接收输入 — 微微侧身，睁大眼睛认真听。
queued: 排队 — 半睁眼安静等待，沙漏表示尚未开始。
thinking: 思考 — 抬眼思考，三个思考点依次出现。
planning: 规划 — 看向一侧，抬眉整理步骤。
delegating: 委派 — 左右转身，分支箭头表示交接任务。
reading: 读取 — 视线逐行移动，查看文件或上下文。
editing: 修改 — 低头轻点，铅笔表示正在修改。
working: 工作中 — 有节奏地起伏；太阳光芒缓慢转动。
executing: 运行工具 — 专注地起伏，终端符号表示工具执行。
verifying: 验证 — 低头检查后点头，核对结果。
reviewing: 审阅 — 歪头慢慢扫视，放大镜表示检查改动。
streaming: 输出回复 — 嘴巴轻轻开合，正在说话。
collecting: 整理结果 — 低头归拢结果，托盘表示收集产物。
waiting: 等待确认 — 歪头提问，等待你的答复或审批。
blocked: 受阻 — 收起笑容，锁表示缺少权限或前置条件。
success: 完成 — 弯眼微笑，轻跳一次后停稳。
error: 失败 — 失落的小表情，感叹号保持静止。
retrying: 重试 — 轻轻调整姿态，回转箭头表示再次尝试。
paused: 暂停 — 半闭眼停住动作，保留继续执行的可能。
cancelled: 取消 — 放松下沉，叉号表示主动终止。
interrupted: 中断 — 睁大眼睛，断线符号表示意外停止。
sleeping: 打盹 — 闭眼缓慢呼吸，睡眠符号轻轻浮动。
connecting: 连接中 — 抬头等待，连接符号缓慢变化。
offline: 离线 — 闭眼静止，降低整体透明度。
